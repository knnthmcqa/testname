package pages;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;

public class LoginPage {

	/**
	 * All WebElements are identified by @Findby Annotation
	 */

	WebDriver driver;

	By emailTxtBx = By.xpath("//*[@id=\"iptLgnPlnID\"]");
	By passwordTxtBx = By.xpath("//*[@id=\"iptLgnPlnPD\"]");
	By signinBttn = By.xpath("/html/body/div[1]/main/div/div/div[1]/form/fieldset/div[7]/button");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

// KG01_Login_To_Admin_Knox_Guard()

	public void inputCredential(String strEmail, String strPassword) {

		driver.findElement(emailTxtBx).sendKeys(strEmail);
		driver.findElement(passwordTxtBx).sendKeys(strPassword);
		driver.findElement(signinBttn).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void login(String strEmail, String strPassword) {
		this.inputCredential(strEmail, strPassword);

	}

}
