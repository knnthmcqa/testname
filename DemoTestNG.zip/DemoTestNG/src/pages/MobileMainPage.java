package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class MobileMainPage {
	AndroidDriver<AndroidElement> androidDriver;

	By enrollBttn = By.id("\"kg-button\"");
	By image = By.xpath("//*[@id=\"landscape\"]/img");
	By checkTxt = By.xpath("com.sec.enterprise.knox.cloudmdm.smdms:id/small_header_title");
	By eulaTitleTxt = By.id("com.samsung.android.kgclient:id/label_eula_title");
	By eulaBodyTxt = By.id("com.samsung.android.kgclient:id/label_eula_body");
	By eulaAgreeBttn = By.id("com.samsung.android.kgclient:id/button_agree");
	public MobileMainPage(AndroidDriver<AndroidElement> androidDriver) {
		this.androidDriver = androidDriver;
	}

	public void clickEnrollButton() throws InterruptedException {

		androidDriver.findElement(By.id("kg-button")).isDisplayed();
		Thread.sleep(3000);
		androidDriver.findElement(image).click();
		Thread.sleep(3000);
		androidDriver.context("NATIVE_APP");
		androidDriver.findElement(By.id("kg-button")).click();
		Thread.sleep(3000);


	}
	
	public void agreeEULA() throws InterruptedException {
		Thread.sleep(10000);
		WebDriverWait wait = new WebDriverWait(androidDriver, 60);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(eulaTitleTxt));
		androidDriver.findElement(eulaBodyTxt).isDisplayed();
		androidDriver.context("NATIVE_APP");
		androidDriver.findElement(eulaAgreeBttn).click();
		Thread.sleep(3000);
	}

}
