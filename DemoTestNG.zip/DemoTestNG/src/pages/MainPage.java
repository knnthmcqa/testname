package pages;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import basePage.Environment;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

public class MainPage {

	WebDriver driver;

	// ============ ADMIN PORTAL ============
	// ============ ============ ============
	// ============ ============ ============

	By devicesBttn = By.xpath("//*[@id=\"linkDevices\"]");
	By searchimeiTxt = By
			.xpath("//*[@id=\"kc-right-content\"]/div[2]/div/div[3]/div/div[3]/div[1]/div/div/div[1]/form/div/input");
	By actionsBttn = By
			.xpath("//*[@id=\"kc-right-content\"]/div[2]/div/div[3]/div/div[3]/div[1]/div/div/div[2]/div/button");
	By policiesBttn = By.xpath("//*[@id=\"linkManageDefault\"]");
	// EULA
	By eulaBttn = By.xpath("/html/body/div[1]/div[2]/div[2]/div/div[2]/div[6]");
	By enableChkBx = By.xpath("//*[@id=\"ng-app\"]/body/div[4]/div/div/div[2]/form/div/div[1]/div[2]/div[1]");
	By titleTxt = By
			.xpath("//*[@id=\"ng-app\"]/body/div[4]/div/div/div[2]/form/div/div[1]/div[2]/div[2]/div/div[2]/input");
	By bodyTxt = By
			.xpath("//*[@id=\"ng-app\"]/body/div[4]/div/div/div[2]/form/div/div[1]/div[2]/div[3]/div/div[2]/textarea");
	By saveBttn = By.xpath("//*[@id=\"ng-app\"]/body/div[4]/div/div/div[2]/form/div/div[2]/button");

	public MainPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public static Environment testEnvironment = ConfigFactory.create(Environment.class);

	@BeforeTest
	public void beforeTest() {
		testEnvironment = ConfigFactory.create(Environment.class);
	}

//SEARCH DEVICE

	public void inputDeviceIMEI(String strIMEI) {

		driver.findElement(devicesBttn).click();
		driver.findElement(searchimeiTxt).sendKeys(strIMEI);
		driver.findElement(searchimeiTxt).sendKeys(Keys.ENTER);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

//EULA	
	public void goToEULA() {

		driver.findElement(policiesBttn).click();
		driver.findElement(eulaBttn).click();
	}

	public void checkEULA() {

		WebDriverWait wait = new WebDriverWait(driver, 60);
		Actions actions = new Actions(driver);

		if (driver.findElement(enableChkBx).isSelected()) {
			System.out.print("EULA is checked.");
		} else {
			wait.until(ExpectedConditions.elementToBeClickable(enableChkBx));
			WebElement element = driver.findElement((enableChkBx));
			actions.moveToElement(element).click().build().perform();
			driver.findElement(saveBttn).click();
		}
	}

	public void uncheckEULA() {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		Actions actions = new Actions(driver);

		if (driver.findElement(enableChkBx).isSelected()) {
			wait.until(ExpectedConditions.elementToBeClickable(enableChkBx));
			WebElement element = driver.findElement((enableChkBx));
			actions.moveToElement(element).click().build().perform();
			driver.findElement(saveBttn).click();
		} else {
			System.out.print("EULA is unchecked.");
		}
	}

	public void inputAgreement(String strTitle, String strBody) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, 60);
		Actions actions = new Actions(driver);

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(titleTxt).click();
		driver.findElement(titleTxt).clear();
		driver.findElement(titleTxt).click();

		wait.until(ExpectedConditions.elementToBeClickable(titleTxt));
		WebElement element1 = driver.findElement((titleTxt));
		actions.moveToElement(element1).sendKeys(strTitle).build().perform();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(bodyTxt).click();
		driver.findElement(bodyTxt).clear();
		driver.findElement(bodyTxt).click();

		wait.until(ExpectedConditions.elementToBeClickable(bodyTxt));
		WebElement element2 = driver.findElement((bodyTxt));
		actions.moveToElement(element2).sendKeys(strBody).build().perform();
		driver.findElement(saveBttn).click();

	}

// ===============================================================================
// ===============================================================================

	// ============ RESELLER PORTAL ============
	// ============ ============ ============
	// ============ ============ ============

	By customerBttn = By.xpath("//*[@id=\"LnbCustomers\"]");
	By customerSearchTxt = By.xpath("//*[@id=\"CustomersSearchInput\"]");
	By uploadDeviceBttn = By.xpath("//*[@id=\"UploadDevices\"]");
	By openFile = By.xpath("//*[@ng-click = 'openFileInput()']");
	By confirmBttn = By.xpath("//*[@id=\"_ConfirmButton\"]");

	String filepath = "C:\\Users\\k.cabaccang\\Desktop\\test.csv";

	public void uploadDeviceToCustomer(String strSearchCustomer) throws AWTException {
		Environment testEnvironment = ConfigFactory.create(Environment.class);
		driver.findElement(customerBttn).click();
		driver.findElement(customerSearchTxt).sendKeys(strSearchCustomer);
		driver.findElement(customerSearchTxt).sendKeys(Keys.ENTER);
		driver.get(testEnvironment.getDBCustomerReseller());
		driver.findElement(uploadDeviceBttn).click();

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(openFile));
		WebElement element = driver.findElement((openFile));
		Actions actions = new Actions(driver);
		actions.moveToElement(element).click().build().perform();

		StringSelection ss = new StringSelection(filepath);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robot.delay(3000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.delay(3000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		// driver.close();

		wait.until(ExpectedConditions.elementToBeClickable(confirmBttn));
		WebElement element1 = driver.findElement(confirmBttn);
		Actions actions1 = new Actions(driver);
		actions1.moveToElement(element1).click().build().perform();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	public void uploadDevice(String strSearchCustomer) throws AWTException {
		this.uploadDeviceToCustomer(strSearchCustomer);
	}

	public void checkUploadSuccess() {

		// DASHBOARD

		// DEVICES

	}

}
