package webSuite;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.By;
import org.testng.annotations.*;
import java.net.MalformedURLException;
import java.io.*;
import pages.LoginPage;
import pages.MainPage;
import basePage.Browser;
import basePage.Environment;

class AdminPortal extends Browser {

	LoginPage login;
	MainPage main;
	Browser B = new Browser();
	Environment testEnvironment;

	@BeforeClass
	@Parameters({ "environment" })
	public void beforeTest(String environment) {
		ConfigFactory.setProperty("env", environment);
		testEnvironment = ConfigFactory.create(Environment.class);
	}

	@Test
	public void KG00_OpenBrowser() throws MalformedURLException {
		System.out.print("KG00 - Go to Knox Guard Admin Portal");
		B.openBrowserAdminPortal();
		// System.out.println(testEnvironment.getDBURLAdmin());
	}

	@Test
	public void KG01_Login_To_Admin_Knox_Guard() throws IOException {
		System.out.println("KG01 - Login To Admin Knox Guard");
		login = new LoginPage(driver);
		login.inputCredential(testEnvironment.getDBUsernameAdmin(), testEnvironment.getDBPasswordAdmin());
	}

	@Test
	public void KG02_Search_Device() throws IOException {
		System.out.println("KG02 - Search Device");
		main = new MainPage(driver);
		main.inputDeviceIMEI("355853100306185");

	}

	@Test
	public void KG03_Custom_EULA() throws IOException, InterruptedException {
		System.out.println("KG03_Custom EULA");
		main = new MainPage(driver);
		main.goToEULA();
		main.checkEULA();
		// main.inputAgreement("TEST AUTOMATION", "TEST AUTOMATION");
		// main.inputcustomEULAShow("TEST AUTO", "TEST AUTO");

	}
}
