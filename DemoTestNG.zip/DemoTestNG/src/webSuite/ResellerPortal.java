package webSuite;

import java.io.*;
import java.net.MalformedURLException;
import org.aeonbits.owner.ConfigFactory;
import org.testng.annotations.*;
import java.awt.*;
import pages.LoginPage;
import pages.MainPage;
import basePage.Browser;
import basePage.Environment;

public class ResellerPortal extends Browser {

	LoginPage login;
	MainPage main;
	Browser B = new Browser();
	Environment testEnvironment;

	@BeforeClass
	@Parameters({ "environment" })
	public void beforeTest(String environment) {
		ConfigFactory.setProperty("env", environment);
		testEnvironment = ConfigFactory.create(Environment.class);
	}

	@Test
	public void KG00_OpenBrowser() throws MalformedURLException {
		System.out.print("KG00 - Go to Knox Guard Reseller Portal");
		B.openBrowserResellerPortal();
	}

	@Test
	public void KG01_Login_To_Admin_Knox_Guard() throws IOException {
		System.out.println("KG01 - Login To Reseller Knox Guard");
		login = new LoginPage(driver);
		login.inputCredential(testEnvironment.getDBUsernameReseller(), testEnvironment.getDBPasswordReseller());
	}

	@Test
	public void KG02_Upload_Device() throws IOException, AWTException {
		System.out.println("KG02 - Upload Device");
		MainPage main;
		main = new MainPage(driver);
		main.uploadDeviceToCustomer("LOCKLOCK");

	}


}