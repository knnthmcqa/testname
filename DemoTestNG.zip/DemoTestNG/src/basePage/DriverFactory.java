package basePage;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.*;
import io.appium.java_client.android.*;
import io.appium.java_client.remote.MobileCapabilityType;

public class DriverFactory {

	private static Map<String, WebDriver> drivers = new HashMap<String, WebDriver>();
	private static String appPath = "C:\\Users\\k.cabaccang\\Desktop\\Google Chrome Fast Secure_v77.0.3865.116_apkpure.com.apk";
	public static String udID;
	public static WebDriver getBrowser(String browserType) throws MalformedURLException {
		WebDriver driver = null;

		switch (browserType) {

		case "Chrome":
			driver = drivers.get("Chrome");
			if (driver == null) {
				System.setProperty("webdriver.chrome.driver",
						"C:\\Users\\k.cabaccang\\Documents\\drivers\\chromedriver.exe");
				driver = new ChromeDriver();
				drivers.put("Chrome", driver);
			}
			break;

		case "Chrome2":
			driver = drivers.get("Chrome2");
			if (driver == null) {
				System.setProperty("webdriver.chrome.driver",
						"C:\\Users\\k.cabaccang\\Documents\\drivers\\chromedriver.exe");
				driver = new ChromeDriver();
				drivers.put("Chrome2", driver);
			}
			break;

		}
		return driver;
	}

	public static AndroidDriver<AndroidElement> setupCapabilities() throws MalformedURLException {

		DesiredCapabilities capabilities = new DesiredCapabilities();
		udID = (String) capabilities.getCapability("udid");

		capabilities.setCapability("deviceName", "Android");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("udid", udID);
		// capabilities.setCapability("appPackage", "com.hmh.api");
		capabilities.setCapability("browserName", "Chrome");
		capabilities.setCapability("clearSystemFiles", true);
		capabilities.setCapability("noReset", true);
		capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "60");
		capabilities.setCapability("appActivity", "com.android.chrome");
		capabilities.setCapability("app", appPath);
		
		

		AndroidDriver<AndroidElement> androidDriver = new AndroidDriver<AndroidElement>(
				new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

		return androidDriver;

	}

	public static void closeAllDriver() {
		for (String key : drivers.keySet()) {
			drivers.get(key).close();
			drivers.get(key).quit();
		}
	}
}