package basePage;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.*;

@Sources({ "classpath:${env}.properties" })

public interface Environment extends Config {

	@Key("db.urlAdmin")
	String getDBURLAdmin();

	@Key("db.urlReseller")
	String getDBURLReseller();

	@Key("db.usernameAdmin")
	String getDBUsernameAdmin();

	@Key("db.passwordAdmin")
	String getDBPasswordAdmin();

	@Key("db.usernameReseller")
	String getDBUsernameReseller();

	@Key("db.passwordReseller")
	String getDBPasswordReseller();
	
	@Key("db.customerReseller")
	String getDBCustomerReseller();
}
