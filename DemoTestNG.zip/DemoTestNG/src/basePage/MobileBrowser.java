package basePage;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class MobileBrowser extends DriverFactory {

	public static AndroidDriver<AndroidElement> androidDriver;
	String appPath = "C:\\Users\\k.cabaccang\\Desktop\\Google Chrome Fast Secure_v77.0.3865.116_apkpure.com.apk";

	public MobileBrowser() {
		// TODO Auto-generated constructor stub
		try {
			androidDriver = setupCapabilities();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void openBrowserMobile() throws MalformedURLException, InterruptedException {

		// AndroidDriver<AndroidElement> androidDriver = setupCapabilities();
		// androidDriver.installApp(appPath);
		androidDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		androidDriver.get("https://guard.samsungknox.com");
		androidDriver.navigate().refresh();

	}
}
