package basePage;


import java.net.MalformedURLException;
import java.sql.DriverManager;
import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import basePage.Environment;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class Browser extends DriverFactory {

	public static DriverManager driverManager;
	public static WebDriver driver;
	public static AndroidDriver<AndroidElement> androidDriver;
	public static Environment testEnvironment = ConfigFactory.create(Environment.class);

	@BeforeTest
	public void beforeTest() {
		testEnvironment = ConfigFactory.create(Environment.class);
	}

	public void openBrowserAdminPortal() throws MalformedURLException {
		Environment testEnvironment = ConfigFactory.create(Environment.class);
		driver = DriverFactory.getBrowser("Chrome2");
		driver.manage().window().maximize();
		driver.get(testEnvironment.getDBURLAdmin());
	}

	public void openBrowserResellerPortal() throws MalformedURLException {
		Environment testEnvironment = ConfigFactory.create(Environment.class);
		driver = DriverFactory.getBrowser("Chrome");
		driver.manage().window().maximize();
		driver.get(testEnvironment.getDBURLReseller());
	}

	public void closeDriver() {
		driver.close();
	}

}
