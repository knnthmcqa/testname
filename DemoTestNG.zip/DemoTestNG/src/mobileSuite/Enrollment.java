package mobileSuite;

import java.net.MalformedURLException;

import org.testng.annotations.*;

import basePage.MobileBrowser;
import pages.MobileMainPage;
public class Enrollment {
	static MobileBrowser B;
	static MobileMainPage page ;
	
	@BeforeTest
	public static void setup() {
		B = new MobileBrowser();
		page = new MobileMainPage(MobileBrowser.androidDriver);
	}

	@Test
	public void KG00_Open_Mobile_Browser() throws MalformedURLException, InterruptedException  {
		System.out.print("KG00 - Open Mobile Browser");
		B.openBrowserMobile();

	}
	@Test
	public void KG01_Enroll_Device() throws MalformedURLException, InterruptedException  {
		System.out.print("KG01 - Enroll Device");
		page.clickEnrollButton();
	}
	
	@Test
	public void KG02_AgreeEULA() throws InterruptedException {
		System.out.print("KG02 - Agree EULA");
		page.agreeEULA();

	}


}
